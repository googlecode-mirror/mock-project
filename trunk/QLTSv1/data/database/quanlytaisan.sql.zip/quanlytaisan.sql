-- phpMyAdmin SQL Dump
-- version 3.3.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 09, 2011 at 07:52 AM
-- Server version: 5.5.11
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `quanlytaisan`
--

-- --------------------------------------------------------

--
-- Table structure for table `historyinfor`
--

CREATE TABLE IF NOT EXISTS `historyinfor` (
  `HistoryID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LUserID` int(8) unsigned NOT NULL,
  `RUserID` int(8) unsigned NOT NULL,
  `ItemID` int(8) unsigned NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`HistoryID`),
  KEY `LUserID` (`LUserID`),
  KEY `RUserID` (`RUserID`),
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `historyinfor`
--


-- --------------------------------------------------------

--
-- Table structure for table `iteminfor`
--

CREATE TABLE IF NOT EXISTS `iteminfor` (
  `ItemID` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `Ma_tai_san` varchar(10) NOT NULL,
  `Ten_tai_san` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Type` enum('0','1') NOT NULL DEFAULT '0',
  `StartDate` date NOT NULL,
  `Price` int(10) NOT NULL,
  `WarrantyTime` int(3) NOT NULL,
  `Status` enum('0','1','2') NOT NULL DEFAULT '0',
  `Place` varchar(12) NOT NULL,
  PRIMARY KEY (`ItemID`),
  UNIQUE KEY `Ma_tai_san` (`Ma_tai_san`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `iteminfor`
--

INSERT INTO `iteminfor` (`ItemID`, `Ma_tai_san`, `Ten_tai_san`, `Description`, `Type`, `StartDate`, `Price`, `WarrantyTime`, `Status`, `Place`) VALUES
(1, '3306', 'Monitor', '17", Flatron', '0', '2011-06-01', 3000000, 36, '0', 'Room 1'),
(2, '3307', 'Case', 'CA Elead P4 631-3.0 A-D945GCNL/512/160G/K/M', '1', '2011-06-01', 5000000, 36, '0', 'Room 1'),
(3, '3308', 'Monitor', '17", Flatron', '0', '2011-06-01', 3000000, 36, '1', 'Room 2'),
(4, '3309', 'Case', 'CA Elead P4 631-3.0 A-D945GCNL/512/160G/K/M', '1', '2011-06-01', 5000000, 36, '1', 'Room 2'),
(5, '3310', 'Monitor', '17", Flatron', '0', '2011-06-02', 3000000, 36, '2', 'Room 3'),
(6, '3311', 'Case', 'CA Elead P4 631-3.0 A-D945GCNL/1024/160G/K/M', '1', '2011-06-02', 5500000, 36, '2', 'Room 3'),
(7, '3312', 'Monitor', '15", Flatron', '1', '2011-06-07', 2500000, 24, '1', 'Room 1'),
(8, '3313', 'Case', 'CA Elead P4 631-3.0 A-D945GCNL/1024/160G/K/M', '0', '2011-06-07', 5500000, 36, '1', 'Room 1');

-- --------------------------------------------------------

--
-- Table structure for table `loaninfor`
--

CREATE TABLE IF NOT EXISTS `loaninfor` (
  `Ma_tai_san` varchar(10) CHARACTER SET utf8 NOT NULL,
  `UserID` int(8) unsigned NOT NULL,
  `Detail` varchar(255) CHARACTER SET utf8 NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`Ma_tai_san`),
  KEY `UserID` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loaninfor`
--

INSERT INTO `loaninfor` (`Ma_tai_san`, `UserID`, `Detail`, `Date`) VALUES
('3308', 2, 'Hoc tap', '2011-06-12'),
('3309', 2, 'Hoc tap', '2011-06-12'),
('3312', 5, 'Hoc tap', '2011-06-20'),
('3313', 5, 'Hoc tap', '2011-06-20');

-- --------------------------------------------------------

--
-- Table structure for table `memberinfor`
--

CREATE TABLE IF NOT EXISTS `memberinfor` (
  `UserID` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Role` enum('3','2','1','0') NOT NULL DEFAULT '3',
  `Email` varchar(50) NOT NULL,
  `FullName` varchar(50) NOT NULL,
  `Group` varchar(5) NOT NULL,
  `Birthday` date DEFAULT NULL,
  `Phone` varchar(30) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `memberinfor`
--

INSERT INTO `memberinfor` (`UserID`, `Username`, `Password`, `Role`, `Email`, `FullName`, `Group`, `Birthday`, `Phone`, `Address`) VALUES
(1, 'sondx', 'sondx12345', '0', 'sondx@fsoft.com.vn', 'Dinh Xuan Son', 'G0', '1989-12-17', '01692562324', 'Ha Noi'),
(2, 'oanhnn', 'oanhnn12345', '3', 'oanhnn@fsoft.com.vn', 'Nguyen Ngoc Oanh', 'G0', NULL, NULL, NULL),
(3, 'thangkc', 'thangkc12345', '2', 'thangkc@fsoft.com.vn', 'Kieu Cao Thang', 'G0', NULL, NULL, NULL),
(4, 'tuanna', 'tuanna12345', '1', 'tuanna@fsoft.com.vn', 'Nguyen Anh Tuan', 'G0', NULL, NULL, NULL),
(5, 'cuongpv', 'cuongpv12345', '3', 'cuongpv@fsoft.com.vn', 'Pham Van Cuong', 'G0', NULL, NULL, NULL),
(6, 'cuongnv', 'cuongnv12345', '3', 'cuongnv@fsoft.com.vn', 'Nguyen Van Cuong', 'G0', NULL, NULL, NULL),
(7, 'oanhnn1', 'oanhnn12345', '0', 'nguyenngocoanh@gmail.com', 'nguyen ngoc oanh', 'G0', NULL, 'oanh', '1222');

-- --------------------------------------------------------

--
-- Table structure for table `messageinfor`
--

CREATE TABLE IF NOT EXISTS `messageinfor` (
  `MessageID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SendID` int(8) unsigned NOT NULL,
  `ReceiveID` int(8) unsigned NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`MessageID`),
  KEY `SendID` (`SendID`),
  KEY `ReceiveID` (`ReceiveID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `messageinfor`
--


-- --------------------------------------------------------

--
-- Table structure for table `requestinfor`
--

CREATE TABLE IF NOT EXISTS `requestinfor` (
  `RequestID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UserID` int(8) unsigned NOT NULL,
  `Ma_tai_san` varchar(10) NOT NULL,
  `Type` enum('0','1') NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  `Accept` enum('0','1','2') NOT NULL DEFAULT '0',
  PRIMARY KEY (`RequestID`),
  KEY `UserID` (`UserID`),
  KEY `Ma_tai_san` (`Ma_tai_san`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `requestinfor`
--


-- --------------------------------------------------------

--
-- Table structure for table `upgradeinfor`
--

CREATE TABLE IF NOT EXISTS `upgradeinfor` (
  `UpgradeID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UserID` int(8) unsigned NOT NULL,
  `ManagerID` int(8) unsigned NOT NULL,
  `ItemID` int(8) unsigned NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`UpgradeID`),
  KEY `UserID` (`UserID`),
  KEY `ManagerID` (`ManagerID`),
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `upgradeinfor`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `historyinfor`
--
ALTER TABLE `historyinfor`
  ADD CONSTRAINT `ItemID` FOREIGN KEY (`ItemID`) REFERENCES `iteminfor` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `LUserID` FOREIGN KEY (`LUserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `RUserID` FOREIGN KEY (`RUserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `loaninfor`
--
ALTER TABLE `loaninfor`
  ADD CONSTRAINT `loaninfor_ibfk_1` FOREIGN KEY (`Ma_tai_san`) REFERENCES `iteminfor` (`Ma_tai_san`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `loaninfor_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `messageinfor`
--
ALTER TABLE `messageinfor`
  ADD CONSTRAINT `messageinfor_ibfk_1` FOREIGN KEY (`SendID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `messageinfor_ibfk_2` FOREIGN KEY (`ReceiveID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `requestinfor`
--
ALTER TABLE `requestinfor`
  ADD CONSTRAINT `requestinfor_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `requestinfor_ibfk_2` FOREIGN KEY (`Ma_tai_san`) REFERENCES `iteminfor` (`Ma_tai_san`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `upgradeinfor`
--
ALTER TABLE `upgradeinfor`
  ADD CONSTRAINT `upgradeinfor_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `upgradeinfor_ibfk_2` FOREIGN KEY (`ManagerID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `upgradeinfor_ibfk_3` FOREIGN KEY (`ItemID`) REFERENCES `iteminfor` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE;
