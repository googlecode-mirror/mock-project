-- phpMyAdmin SQL Dump
-- version 3.3.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 18, 2011 at 10:39 PM
-- Server version: 5.5.11
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `quanlytaisan`
--

-- --------------------------------------------------------

--
-- Table structure for table `historyinfor`
--

CREATE TABLE IF NOT EXISTS `historyinfor` (
  `HistoryID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LUserID` int(8) unsigned NOT NULL,
  `RUserID` int(8) unsigned NOT NULL,
  `ItemID` int(8) unsigned NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`HistoryID`),
  KEY `LUserID` (`LUserID`),
  KEY `RUserID` (`RUserID`),
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `historyinfor`
--


-- --------------------------------------------------------

--
-- Table structure for table `iteminfor`
--

CREATE TABLE IF NOT EXISTS `iteminfor` (
  `ItemID` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `Ma_tai_san` varchar(10) NOT NULL,
  `Ten_tai_san` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Type` enum('0','1') NOT NULL DEFAULT '0',
  `StartDate` date NOT NULL,
  `Price` int(10) NOT NULL,
  `WarrantyTime` int(3) NOT NULL,
  `Status` enum('0','1','2') NOT NULL DEFAULT '0',
  `Place` varchar(12) NOT NULL,
  PRIMARY KEY (`ItemID`),
  UNIQUE KEY `Ma_tai_san` (`Ma_tai_san`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `iteminfor`
--


-- --------------------------------------------------------

--
-- Table structure for table `loaninfor`
--

CREATE TABLE IF NOT EXISTS `loaninfor` (
  `Ma_tai_san` varchar(10) CHARACTER SET utf8 NOT NULL,
  `UserID` int(8) unsigned NOT NULL,
  `Detail` varchar(255) CHARACTER SET utf8 NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`Ma_tai_san`),
  KEY `UserID` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loaninfor`
--


-- --------------------------------------------------------

--
-- Table structure for table `memberinfor`
--

CREATE TABLE IF NOT EXISTS `memberinfor` (
  `UserID` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(64) NOT NULL,
  `Role` enum('3','2','1','0') NOT NULL DEFAULT '3',
  `Email` varchar(50) NOT NULL,
  `FullName` varchar(50) NOT NULL,
  `Group` varchar(5) NOT NULL,
  `Birthday` date DEFAULT NULL,
  `Phone` varchar(30) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `memberinfor`
--

INSERT INTO `memberinfor` (`UserID`, `Username`, `Password`, `Role`, `Email`, `FullName`, `Group`, `Birthday`, `Phone`, `Address`) VALUES
(11, 'sondx', 'e37ff61c7a547c8dd974455ff60cae96670a2b0aa66631edeefecd4a41157fbc', '0', 'sondx@fsoft.com.vn', 'Đinh Xuân Sơn', 'G0', '2011-07-18', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messageinfor`
--

CREATE TABLE IF NOT EXISTS `messageinfor` (
  `MessageID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SendID` int(8) unsigned NOT NULL,
  `ReceiveID` int(8) unsigned NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Detail` text NOT NULL,
  `Time` datetime NOT NULL,
  `Readed` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`MessageID`),
  KEY `SendID` (`SendID`),
  KEY `ReceiveID` (`ReceiveID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `messageinfor`
--


-- --------------------------------------------------------

--
-- Table structure for table `requestinfor`
--

CREATE TABLE IF NOT EXISTS `requestinfor` (
  `RequestID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UserID` int(8) unsigned NOT NULL,
  `Ma_tai_san` varchar(10) NOT NULL,
  `Type` enum('0','1') NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  `Accept` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`RequestID`),
  KEY `UserID` (`UserID`),
  KEY `Ma_tai_san` (`Ma_tai_san`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `requestinfor`
--


-- --------------------------------------------------------

--
-- Table structure for table `upgradeinfor`
--

CREATE TABLE IF NOT EXISTS `upgradeinfor` (
  `UpgradeID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UserID` int(8) unsigned NOT NULL,
  `ManagerID` int(8) unsigned NOT NULL,
  `ItemID` int(8) unsigned NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`UpgradeID`),
  KEY `UserID` (`UserID`),
  KEY `ManagerID` (`ManagerID`),
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `upgradeinfor`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `historyinfor`
--
ALTER TABLE `historyinfor`
  ADD CONSTRAINT `ItemID` FOREIGN KEY (`ItemID`) REFERENCES `iteminfor` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `LUserID` FOREIGN KEY (`LUserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `RUserID` FOREIGN KEY (`RUserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `loaninfor`
--
ALTER TABLE `loaninfor`
  ADD CONSTRAINT `loaninfor_ibfk_1` FOREIGN KEY (`Ma_tai_san`) REFERENCES `iteminfor` (`Ma_tai_san`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `loaninfor_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `messageinfor`
--
ALTER TABLE `messageinfor`
  ADD CONSTRAINT `messageinfor_ibfk_1` FOREIGN KEY (`SendID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `messageinfor_ibfk_2` FOREIGN KEY (`ReceiveID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `requestinfor`
--
ALTER TABLE `requestinfor`
  ADD CONSTRAINT `requestinfor_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `requestinfor_ibfk_2` FOREIGN KEY (`Ma_tai_san`) REFERENCES `iteminfor` (`Ma_tai_san`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `upgradeinfor`
--
ALTER TABLE `upgradeinfor`
  ADD CONSTRAINT `upgradeinfor_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `upgradeinfor_ibfk_2` FOREIGN KEY (`ManagerID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `upgradeinfor_ibfk_3` FOREIGN KEY (`ItemID`) REFERENCES `iteminfor` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE;
