-- phpMyAdmin SQL Dump
-- version 3.3.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 19, 2011 at 10:49 AM
-- Server version: 5.5.11
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `quanlytaisan`
--

-- --------------------------------------------------------

--
-- Table structure for table `historyinfor`
--

CREATE TABLE IF NOT EXISTS `historyinfor` (
  `HistoryID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LUserID` int(8) unsigned NOT NULL,
  `RUserID` int(8) unsigned NOT NULL,
  `ItemID` int(8) unsigned NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`HistoryID`),
  KEY `LUserID` (`LUserID`),
  KEY `RUserID` (`RUserID`),
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `historyinfor`
--

INSERT INTO `historyinfor` (`HistoryID`, `LUserID`, `RUserID`, `ItemID`, `Detail`, `Date`) VALUES
(1, 12, 16, 14, 'Mượn', '2011-07-19'),
(2, 12, 17, 21, 'Cho mượn...', '2011-07-19'),
(3, 12, 19, 27, 'Cho mượn', '2011-07-19'),
(4, 19, 12, 27, 'Tra thiet bi', '2011-07-19');

-- --------------------------------------------------------

--
-- Table structure for table `iteminfor`
--

CREATE TABLE IF NOT EXISTS `iteminfor` (
  `ItemID` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `Ma_tai_san` varchar(10) NOT NULL,
  `Ten_tai_san` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Type` enum('0','1') NOT NULL DEFAULT '0',
  `StartDate` date NOT NULL,
  `Price` int(10) NOT NULL,
  `WarrantyTime` int(3) NOT NULL,
  `Status` enum('0','1','2') NOT NULL DEFAULT '0',
  `Place` varchar(12) NOT NULL,
  PRIMARY KEY (`ItemID`),
  UNIQUE KEY `Ma_tai_san` (`Ma_tai_san`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `iteminfor`
--

INSERT INTO `iteminfor` (`ItemID`, `Ma_tai_san`, `Ten_tai_san`, `Description`, `Type`, `StartDate`, `Price`, `WarrantyTime`, `Status`, `Place`) VALUES
(10, '305512', 'Case', 'CA Elead P4 630-3.0 AD945GCCRL/1G/80G/K/M/\n', '0', '2011-07-18', 5000000, 12, '0', 'Kho'),
(11, '305569', 'Case', 'CA Elead P4 631-3.0 A-D945GCNL/512/160G/K/M\n', '0', '2011-07-06', 4000000, 24, '0', 'Kho\n'),
(12, '305567', 'Case', 'CA Elead P4 631-3.0 A-D945GCNL/512/160G/K/M\n', '0', '2011-07-11', 4000000, 15, '0', 'Kho'),
(13, '305568', 'Case', 'CA Elead P4 631-3.0 A-D945GCNL/512/160G/K/M\n', '0', '2011-07-18', 3500000, 40, '0', 'Kho'),
(14, '305560', 'Case', 'CA Elead P4-2.66 Main/G915GL-M9/1G/40G/K/M/\n', '0', '2011-07-11', 5600000, 24, '1', 'Lab 1'),
(16, '305561', 'Case', 'CA Elead P4-2.66/CP5GL-TMX/S/512M/40G/K/M/\n', '0', '2011-07-11', 5000000, 12, '2', 'Kho'),
(17, '5000', 'Monitor', 'Monitor LG LCD 1550SQ-SN\n', '1', '2011-07-18', 2000000, 14, '0', 'Kho'),
(18, '5001', 'Monitor', 'Monitor LG 15 1552S LCD\n', '1', '2011-07-11', 2000000, 16, '0', 'Kho'),
(19, '5002', 'Monitor', 'MO LCD 15"\n', '1', '2011-07-12', 3000000, 10, '0', 'Kho'),
(20, '5003', 'Monitor', 'Monitor LG L 1550S-SN LCD\n', '1', '2011-07-11', 1200000, 12, '0', 'Kho\n'),
(21, '5004', 'Monitor', 'Monitor LG L1553SLCD\n', '1', '2011-07-05', 2000000, 24, '1', 'Lab 1'),
(22, '5005', 'Monitor', 'MO Monitor Elead 17"L1742S LCD\n', '1', '2011-07-03', 3500000, 15, '0', 'Kho'),
(23, '1000', 'Máy ảnh', 'Máy ảnh Canon A710IS\n', '1', '2011-07-05', 7000000, 24, '0', 'Kho'),
(24, '1001', 'Máy ghi âm', 'Máy ghi âm JVJ DVR-950 (512MB)\n', '1', '2011-07-12', 5000000, 12, '0', 'Kho\n'),
(25, '1002', 'Máy chiếu', 'Màn chiếu điện Dalite 150 inch\n', '1', '2011-07-05', 3000000, 16, '0', 'Kho\n'),
(26, '100', 'RAM', 'RAM 1GB', '1', '2011-07-12', 500000, 14, '0', 'Kho'),
(27, '123', 'Laptop', 'Vaio', '0', '2011-07-19', 5000000, 24, '0', 'Kho');

-- --------------------------------------------------------

--
-- Table structure for table `loaninfor`
--

CREATE TABLE IF NOT EXISTS `loaninfor` (
  `Ma_tai_san` varchar(10) CHARACTER SET utf8 NOT NULL,
  `UserID` int(8) unsigned NOT NULL,
  `Detail` varchar(255) CHARACTER SET utf8 NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`Ma_tai_san`),
  KEY `UserID` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loaninfor`
--

INSERT INTO `loaninfor` (`Ma_tai_san`, `UserID`, `Detail`, `Date`) VALUES
('305560', 16, 'Mượn', '2011-07-19'),
('5004', 17, 'Cho mượn...', '2011-07-19');

-- --------------------------------------------------------

--
-- Table structure for table `memberinfor`
--

CREATE TABLE IF NOT EXISTS `memberinfor` (
  `UserID` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(64) NOT NULL,
  `Role` enum('3','2','1','0') NOT NULL DEFAULT '3',
  `Email` varchar(50) NOT NULL,
  `FullName` varchar(50) NOT NULL,
  `Group` varchar(5) NOT NULL,
  `Birthday` date DEFAULT NULL,
  `Phone` varchar(30) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `memberinfor`
--

INSERT INTO `memberinfor` (`UserID`, `Username`, `Password`, `Role`, `Email`, `FullName`, `Group`, `Birthday`, `Phone`, `Address`) VALUES
(11, 'sondx', 'e37ff61c7a547c8dd974455ff60cae96670a2b0aa66631edeefecd4a41157fbc', '0', 'sondx@fsoft.com.vn', 'Đinh Xuân Sơn', 'G0', '2011-07-18', NULL, NULL),
(12, 'oanhnn', 'bdfa29e9ba24dd39ae39672b88929ec79c0dcdfbe24737d5e71218ce9f61be21', '1', 'oanhnn@fsoft.com.vn', 'Nguyễn Ngọc Oanh', 'G0', NULL, '', ''),
(13, 'thangkc', '0a8bd3d9a84852e0fa9aefc0744a8ffa43602bb5edeb71bcfde3079932755955', '1', 'thangkc@gmail.com', 'Kieu Cao Thang', 'G0', '2011-07-18', '', ''),
(14, 'cuongpv', 'c8176b89338b290083dfae1076ab5d600ac5bb704a6c234d8d20e5e9fcfc54df', '2', 'cuongpv@gmail.com', 'Phạm Văn Cương', 'G0', '2011-07-18', '', ''),
(15, 'cuonghm', '322d5c3221b62783a1d6b16a865f941d71508ca47322ff43e9a934bc9ea15520', '3', 'cuonghm@gmail.com', 'Hoàng Minh Cường', 'G0', NULL, '', ''),
(16, 'tuanna', '0aa8934bdedd364738a216cacf1de851df448dcf077f8c0d80bf7d117525625c', '3', 'tuanna12345@gmail.com', 'Nguyễn Anh Tuấn', 'G0', '2011-07-18', '', ''),
(17, 'hoannc', 'a88e647b3947cece6d6f99bd6c3b745a9b48271dbc1a0614d159d54c1153b4c0', '3', 'hoannc@gmail.com', 'Nguyễn Công Hoàn', 'G0', '2011-07-18', '', ''),
(19, 'haipt', 'adcf5c6f6a722febede29503d77f516834811ef53fa81fffda3bb1d4b8766ae5', '3', 'haipt@gmail.com', 'Hai', 'G0', '2011-07-19', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `messageinfor`
--

CREATE TABLE IF NOT EXISTS `messageinfor` (
  `MessageID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SendID` int(8) unsigned NOT NULL,
  `ReceiveID` int(8) unsigned NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Detail` text NOT NULL,
  `Time` datetime NOT NULL,
  `Readed` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`MessageID`),
  KEY `SendID` (`SendID`),
  KEY `ReceiveID` (`ReceiveID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `messageinfor`
--

INSERT INTO `messageinfor` (`MessageID`, `SendID`, `ReceiveID`, `Title`, `Detail`, `Time`, `Readed`) VALUES
(1, 12, 16, 'Thông báo: Yêu cầu mượn được chấp nhận', 'Yêu cầu mượn tài sản 305560 đã được chấp nhận. Bạn hãy gặp tôi sơm nhất để nhận tài sản', '2011-07-19 09:05:11', '0'),
(2, 14, 16, 'Thông báo: Yêu cầu nâng cấp được chấp nhận', 'Yêu cầu nâng cấp tài sản 305560 đã được chấp nhận. Bạn hãy gặp tôi sơm nhất để được nâng cấp tài sản', '2011-07-19 09:07:58', '0'),
(3, 13, 16, 'Thông báo: Yêu cầu mượn bị từ chối', 'Yêu cầu mượn tài sản 5004 bị từ chối. Bạn có thể mượn tà sản khác hoặc mượn vào lúc khác', '2011-07-19 09:13:25', '0'),
(5, 12, 19, 'Thông báo: Yêu cầu mượn được chấp nhận', 'Yêu cầu mượn tài sản 123 đã được chấp nhận. Bạn hãy gặp tôi sơm nhất để nhận tài sản', '2011-07-19 10:10:26', '0'),
(6, 14, 17, 'Thông báo: Yêu cầu nâng cấp bị từ chối', 'Yêu cầu nâng cấp tài sản 5004 bị từ chối. Bạn có thể mượn tà sản khác hoặc yêu cầu nâng cấp lúc khác', '2011-07-19 10:13:36', '0'),
(7, 14, 17, 'Thông báo: Yêu cầu nâng cấp được chấp nhận', 'Yêu cầu nâng cấp tài sản 5004 đã được chấp nhận. Bạn hãy gặp tôi sơm nhất để được nâng cấp tài sản', '2011-07-19 10:14:24', '0');

-- --------------------------------------------------------

--
-- Table structure for table `requestinfor`
--

CREATE TABLE IF NOT EXISTS `requestinfor` (
  `RequestID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UserID` int(8) unsigned NOT NULL,
  `Ma_tai_san` varchar(10) NOT NULL,
  `Type` enum('0','1') NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  `Accept` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`RequestID`),
  KEY `UserID` (`UserID`),
  KEY `Ma_tai_san` (`Ma_tai_san`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `requestinfor`
--

INSERT INTO `requestinfor` (`RequestID`, `UserID`, `Ma_tai_san`, `Type`, `Detail`, `Date`, `Accept`) VALUES
(5, 17, '5000', '0', 'mượn cho lab ', '2011-07-19', '0');

-- --------------------------------------------------------

--
-- Table structure for table `upgradeinfor`
--

CREATE TABLE IF NOT EXISTS `upgradeinfor` (
  `UpgradeID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UserID` int(8) unsigned NOT NULL,
  `ManagerID` int(8) unsigned NOT NULL,
  `ItemID` int(8) unsigned NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`UpgradeID`),
  KEY `UserID` (`UserID`),
  KEY `ManagerID` (`ManagerID`),
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `upgradeinfor`
--

INSERT INTO `upgradeinfor` (`UpgradeID`, `UserID`, `ManagerID`, `ItemID`, `Detail`, `Date`) VALUES
(1, 17, 14, 21, 'Nâng cấp', '2011-07-19');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `historyinfor`
--
ALTER TABLE `historyinfor`
  ADD CONSTRAINT `ItemID` FOREIGN KEY (`ItemID`) REFERENCES `iteminfor` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `LUserID` FOREIGN KEY (`LUserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `RUserID` FOREIGN KEY (`RUserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `loaninfor`
--
ALTER TABLE `loaninfor`
  ADD CONSTRAINT `loaninfor_ibfk_1` FOREIGN KEY (`Ma_tai_san`) REFERENCES `iteminfor` (`Ma_tai_san`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `loaninfor_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `messageinfor`
--
ALTER TABLE `messageinfor`
  ADD CONSTRAINT `messageinfor_ibfk_1` FOREIGN KEY (`SendID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `messageinfor_ibfk_2` FOREIGN KEY (`ReceiveID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `requestinfor`
--
ALTER TABLE `requestinfor`
  ADD CONSTRAINT `requestinfor_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `requestinfor_ibfk_2` FOREIGN KEY (`Ma_tai_san`) REFERENCES `iteminfor` (`Ma_tai_san`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `upgradeinfor`
--
ALTER TABLE `upgradeinfor`
  ADD CONSTRAINT `upgradeinfor_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `upgradeinfor_ibfk_2` FOREIGN KEY (`ManagerID`) REFERENCES `memberinfor` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `upgradeinfor_ibfk_3` FOREIGN KEY (`ItemID`) REFERENCES `iteminfor` (`ItemID`) ON DELETE CASCADE ON UPDATE CASCADE;
